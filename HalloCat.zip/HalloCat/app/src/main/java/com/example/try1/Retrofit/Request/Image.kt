    package com.example.try1.Retrofit.Request

    data class Image(
        val id: Int,
        val file_location: String,
        val is_primary: Int
    )
