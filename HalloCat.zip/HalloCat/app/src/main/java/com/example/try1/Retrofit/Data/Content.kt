package com.example.try1.Retrofit.Data

data class Content(
    val title: String,
    val short_description: String,
    val description: String
)
