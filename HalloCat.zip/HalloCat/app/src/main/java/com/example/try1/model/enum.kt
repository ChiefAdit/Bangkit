package com.example.try1.model

enum class enum {
}