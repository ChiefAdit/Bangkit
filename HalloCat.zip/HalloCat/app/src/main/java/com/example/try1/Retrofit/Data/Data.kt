package com.example.try1.Retrofit.Data

data class Data(
    val email: String,
    val id: Int,
    val name: String,
    val role: String,
    val token: String
)