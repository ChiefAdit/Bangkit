package com.example.try1.Retrofit.socketio_android

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.try1.R

class EntranceActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entrance)
    }
}